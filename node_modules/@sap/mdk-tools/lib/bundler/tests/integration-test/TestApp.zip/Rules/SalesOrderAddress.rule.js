var AddressLine, clientAPI;

/**
 * Describe this function...
 */
export default function SalesOrderAddress(clientAPI) {
  AddressLine = String(AddressLine) + String(clientAPI.executeTargetPath("#CurrentObject/#Property:HouseNumber"));
  AddressLine = String(AddressLine) + String(' ');
  AddressLine = String(AddressLine) + String(clientAPI.executeTargetPath("#CurrentObject/#Property:Street"));
  return AddressLine;
}
