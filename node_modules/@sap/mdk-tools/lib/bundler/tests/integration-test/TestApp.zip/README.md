This project contains the SEAM Editor application definitons corresponding to the step by step wiki sample.

The step by step instructions can be found at https://wiki.wdf.sap.corp/wiki/display/tango/App+Modeler+Demo+Environment

Please feel free to report any issues or suggestions to me at bill.froelich@sap.com

Thanks!